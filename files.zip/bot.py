import discord
from discord.ext import tasks
import gspread
from google.oauth2.service_account import Credentials
from datetime import datetime, timedelta
import pytz
import os
from dotenv import load_dotenv

# =========================
# 🔧 CONFIG (EDIT ONLY THIS)
# =========================

TIMEZONE = "Asia/Kolkata"

# Availability
AVAILABILITY_INTERVAL_HOURS = 48
LOOKAHEAD_DAYS = 4

# Session reminders
PREVIOUS_DAY_TIME = (16, 30)
MORNING_TIME = (12, 0)
REMINDER_HOURS_BEFORE = [2]

# System
SESSION_CHECK_INTERVAL_MINUTES = 1

# =========================
# 🔗 SHEET BUTTON
# =========================

SHEET_LINK = "https://docs.google.com/spreadsheets/d/1MvOltJOscJqEkHbr4hYiAzKCIJ_zayHGM9zr2F7APj0/edit?gid=0#gid=0"

class SheetView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(discord.ui.Button(
            label="📊 Open DnD Schedule",
            url=SHEET_LINK
        ))

# =========================

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN")
CHANNEL_ID = int(os.getenv("CHANNEL_ID"))
SHEET_URL = os.getenv("SHEET_URL")

intents = discord.Intents.default()
client = discord.Client(intents=intents)

# =========================
# GOOGLE SHEETS
# =========================

scope = [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive"
]

creds = Credentials.from_service_account_file("credentials.json", scopes=scope)
gc = gspread.authorize(creds)

# =========================
# STATIC CONFIG
# =========================

PLAYERS = ["AZIR", "VARIS", "ALERIA", "SILVER", "IGRIS", "DUNGEON MASTER"]

PLAYER_MAP = {
    "AZIR": 828547252904656927,
    "VARIS": 936184431822143550,
    "ALERIA": 1188529810532741240,
    "SILVER": 1151570200353832960,
    "IGRIS": 1208797835844259841,
    "DUNGEON MASTER": 828606135057645588,
}

VALID = ["AVAILABLE", "UNAVAILABLE"]

tz = pytz.timezone(TIMEZONE)

sent_flags = set()

# =========================
# HELPERS
# =========================

def get_data():
    return gc.open_by_url(SHEET_URL).worksheet("Schedule").get_all_records()

def parse_start_time(timeslot, date_str):
    try:
        start = timeslot.split("to")[0].strip()
        dt = datetime.strptime(f"{date_str} {start}", "%d-%m-%Y %H:%M")
        return tz.localize(dt)
    except:
        return None

def box(msg):
    return (
        "--------------------------------------------------\n"
        + msg +
        "\n--------------------------------------------------"
    )

# =========================
# AVAILABILITY
# =========================

@tasks.loop(hours=AVAILABILITY_INTERVAL_HOURS)
async def check_availability():
    print("Running availability check...")

    now = datetime.now(tz)
    data = get_data()

    next_days = [
        (now + timedelta(days=i)).strftime("%d-%m-%Y")
        for i in range(1, LOOKAHEAD_DAYS + 1)
    ]

    summary = {}

    for player in PLAYERS:
        missing = []

        for row in data:
            if row["DATE"] in next_days:
                val = str(row[player]).strip().upper()
                if val not in VALID:
                    missing.append(row["DATE"])

        if missing:
            summary[player] = missing

    if not summary:
        print("No missing availability.")
        return

    channel = client.get_channel(CHANNEL_ID)

    msg = "⚠️ **Availability Missing**\n\n"

    for p, dates in summary.items():
        uid = PLAYER_MAP[p]
        msg += f"<@{uid}>:\n"
        for d in dates:
            msg += f"  📅 {d}\n"
        msg += "\n"

    await channel.send(box(msg), view=SheetView())

# =========================
# SESSION REMINDERS
# =========================

@tasks.loop(minutes=SESSION_CHECK_INTERVAL_MINUTES)
async def check_sessions():
    data = get_data()
    now = datetime.now(tz)

    channel = client.get_channel(CHANNEL_ID)

    for row in data:
        if row["RESULT"].strip().upper() != "SCHEDULED":
            continue

        start = parse_start_time(row["TIMESLOT"], row["DATE"])
        if not start:
            continue

        # --- Previous Day ---
        prev_day = (start - timedelta(days=1)).replace(
            hour=PREVIOUS_DAY_TIME[0],
            minute=PREVIOUS_DAY_TIME[1]
        )

        key = f"{row['DATE']}_prev"

        if key not in sent_flags and abs((now - prev_day).total_seconds()) < 60:
            sent_flags.add(key)

            await channel.send(box(
                "@everyone 🎲 **Session Reminder**\n"
                f"📅 {row['DATE']} ({row['DAY']})\n"
                f"⏰ {row['TIMESLOT']}"
            ), view=SheetView())

        # --- Morning ---
        morning = start.replace(
            hour=MORNING_TIME[0],
            minute=MORNING_TIME[1]
        )

        key = f"{row['DATE']}_morning"

        if key not in sent_flags and abs((now - morning).total_seconds()) < 60:
            sent_flags.add(key)

            await channel.send(box(
                "@everyone 🎲 **Session Reminder**\n"
                f"📅 {row['DATE']} ({row['DAY']})\n"
                f"⏰ {row['TIMESLOT']}"
            ), view=SheetView())

        # --- Hours Before ---
        for h in REMINDER_HOURS_BEFORE:
            trigger = start - timedelta(hours=h)
            key = f"{row['DATE']}_{h}h"

            if key not in sent_flags and abs((now - trigger).total_seconds()) < 60:
                sent_flags.add(key)

                await channel.send(box(
                    "@everyone 🎲 **Session Reminder**\n"
                    f"📅 {row['DATE']} ({row['DAY']})\n"
                    f"⏰ {row['TIMESLOT']}"
                ), view=SheetView())

# =========================
# START
# =========================

@client.event
async def on_ready():
    print(f"Logged in as {client.user}")

    check_availability.start()
    check_sessions.start()

client.run(TOKEN)